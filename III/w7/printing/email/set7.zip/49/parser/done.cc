#include "parser.ih"

void Parser::done()
{
    cout << "Bye\n";
    ACCEPT();
}

#include "charcount.ih"

CharCount::CharInfo *CharCount::info()
{
  return &d_charObject;

}

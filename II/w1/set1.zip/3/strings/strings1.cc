#include "strings.ih"

Strings::Strings()
:
    d_str(rawPointers(1))
{}

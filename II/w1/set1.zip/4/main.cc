#include "main.ih"

int main(int argc, char **argv)
{

    //Strings str{ environ };

    //cout << str;

    Strings str2;
    cin >> str2;

    cout << str2;


}

#include "strings.ih"

Strings::~Strings()
{
  destroy();
}

#include "filter.ih"

Filter::~Filter()
{
  
}
